<?php 
   $title = 'Customer Call Back Request Report';
   include('../includes/admin-head.php'); 
   include('../config/dbcon.php');
   ?>
<div class="row">
   <div class="col-12">
      <div class="card">
         <div class="card-header">
            <h4>Advanced Table</h4>
            <div class="card-header-form">
               <form>
                  <div class="input-group">
                     <input type="text" class="form-control" placeholder="Search">
                     <div class="input-group-btn">
                        <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                     </div>
                  </div>
               </form>
            </div>
            <div class="card-header-form">
               <form>
                    
                        <select class="form-control">
                           <option value="">Export</option>
                           <option>Excel</option>
                        </select>
                    
               </form>
            </div>
         </div>
         <div class="card-body p-0">
            <div class="table-responsive">
               <table class="table table-striped v_center">
                  <tr>
                     <th>
                        <div class="custom-checkbox custom-control">
                           <input type="checkbox" data-checkboxes="mygroup" data-checkbox-role="dad" class="custom-control-input" id="checkbox-all">
                           <label for="checkbox-all" class="custom-control-label">&nbsp;</label>
                        </div>
                     </th>
                     <th>Customer Name</th>
                     <th>Email ID</th>
                     <th>Mobile Number</th>
                     <th>Created Date</th>
                     <th>Action</th>
                  </tr>
                  <tr>
                     <td class="p-0 text-center">
                        <div class="custom-checkbox custom-control">
                           <input type="checkbox" data-checkboxes="mygroup" class="custom-control-input" id="checkbox-1">
                           <label for="checkbox-1" class="custom-control-label">&nbsp;</label>
                        </div>
                     </td>
                     <td>Create a mobile app</td>
                     <td class="align-middle">
                        <div class="progress" data-height="4" data-toggle="tooltip" title="100%">
                           <div class="progress-bar bg-success" data-width="100"></div>
                        </div>
                     </td>
                     <td>
                        <img alt="image" src="assets/img/avatar/avatar-5.png" class="rounded-circle" width="35" data-toggle="tooltip" title="Wildan Ahdian">
                     </td>
                     <td>2018-01-20</td>
                     <td><a href="#" class="btn btn-secondary">Deleted</a></td>
                  </tr>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>