<?php
   $title= 'Categories Updates';
   include('../includes/admin-head.php');
   include('../config/dbcon.php');
   include('../code/function.php');
   ?>
<div class="main-content">
   <section class="section">
      <div class="section-header">
         <div class="section-header-back">
            <a href="../created/categories-created.php" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
         </div>
         <h1>Updates Categories</h1>
         <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="#">Dashboard</a></div>
            <div class="breadcrumb-item"><a href="#">Posts</a></div>
            <div class="breadcrumb-item">Updates Categories</div>
         </div>
      </div>
      <div class="section-body">
         <div class="col-12 col-md-6 col-lg-12">
            <div class="card">
               <?php
                  if(isset($GET['cat_id']))
                  {
                     $category_id = $_GET['cat_id'];
                     $category_edit = "SELECT * FROM categories WHERE cat_id='$category_id' LIMIT 1 ";
                     $category_run = mysqli_query($conn, $category_edit);

                     if(mysqli_num_rows($category_run) > 0)
                     {
                  
                        $row = mysqli_fetch_array($category_run);
                        {
                        ?>
                 
                     <form action="">
                  <div class="card-header">
                     <h4>Updates Categories Area</h4>
                  </div>
                  <div class="card-body">
                     <div class="form-group">
                        <label>Category Name</label>
                        <input name="cat_name" value="<?=$row['cat_name'];?>"  class="form-control" placeholder="Please enter categories name" required="">
                     </div>
                     <div class="form-group mb-0">
                        <label>Description</label>
                        <textarea name="cat_desc"  class="form-control" placeholder="Please enter about self category" required=""></textarea>
                     </div>
                     <div class="form-group">
                        <label>Meta Keword</label>
                        <input type="meta_desc" name="meta_desc"class="form-control" placeholder="Please enter meta keywords" required="">
                     </div>
                  </div>
                  <div class="card-footer text-right">
                     <button name="category_updates" class="btn btn-primary">Update Category</button>
                  </div>
               </form>
               <?php
                  }
                  }else{
                     ?>
               <?php
                  }
                  }
                  ?> 
            </div>
         </div>
      </div>
   </section>
</div>