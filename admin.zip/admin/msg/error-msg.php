<?php  
   if(isset($_SESSION['status']))
   {
    ?>
        <div class="alert alert-danger" role="alert">
        <h4 style="color: white" class="alert-link"><?php echo $_SESSION['status']; ?> !</h4>
        </div>
    <?php
   unset($_SESSION['status']);
   }
?>