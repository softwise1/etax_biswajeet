<?php
   $title= 'Created Categories';
   include('../includes/admin-head.php');
   include('../config/dbcon.php');
   include('../code/function.php');
?>

<div class="main-content">
   <section class="section">
      <div class="section-header">
         <div class="section-header-back">
            <a href="../created/sub-categories-created.php" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
         </div>
         <h1>Create New Sub Categories</h1>
         <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="#">Dashboard</a></div>
            <div class="breadcrumb-item"><a href="#">Posts</a></div>
            <div class="breadcrumb-item">Create New Sub Categories</div>
         </div>
      </div>
      <div class="section-body">

         <div class="col-12 col-md-6 col-lg-12">
            <div class="card">
               <form action="../code/function.php" method="POST">
                  <div class="card-header">
                     <h4>Created Sub Category Area</h4>
                  </div>
                  <div class="card-body">
                     <div class="form-group">
                        <label>Sub Category Name</label>
                        <input  name="subcat_name" class="form-control" placeholder="Please enter categories name" required="">
                     </div>
                     <div class="form-group mb-0">
                        <label>Sub Description</label>
                        <textarea name="subcat_desc" class="form-control" placeholder="Please enter about self category" required=""></textarea>
                     </div>
                     <div class="form-group">
                        <label>Sub Meta Keword</label>
                        <input name="submeta_desc" class="form-control" placeholder="Please enter meta keywords" required="">
                     </div>
                  </div>
                  <div class="card-footer text-right">
                     <button name="subcategory_add" class="btn btn-primary">Add SubCategory</button>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </section>
</div>