<?php 
$title = 'Centent Post';
include('../includes/admin-head.php'); 
include('../config/dbcon.php');
?>

      
<div class="main-content">
   <section class="section">
      <div class="section-header">
         <div class="section-header-back">
            <a href="../created/font-categories-created.php" class="btn btn-icon"><i class="fas fa-arrow-left"></i></a>
         </div>
         <h1>Create New Centent</h1>
         <div class="section-header-breadcrumb">
            <div class="breadcrumb-item active"><a href="#">Dashboard</a></div>
            <div class="breadcrumb-item"><a href="#">Posts</a></div>
            <div class="breadcrumb-item">Create New Centent</div>
         </div>
      </div>
      <div class="section-body">
         <h2 class="section-title">Message...</h2>
         <!-- <p class="section-lead">On this page you can create a new post and fill in all fields.</p> -->
         <div class="col-12 col-md-6 col-lg-12">
            <div class="card">
               <form>
                  <div class="card-header">
                     <h4>New Content Post</h4>
                  </div>
                  <div class="card-body">
                     <div class="form-group">
                        <label>Package Name:</label>
                        <input type="text" class="form-control">
                     </div>
                     <div class="form-group">
                        <label>Category:</label>
                        <select class="form-control">
                           <option>Option 1</option>
                        </select>
                     </div>
                     <div class="form-group">
                        <label>Sub Category:</label>
                        <select class="form-control">
                           <option>Option 2</option>
                        </select>
                     </div>
                     <div class="form-group">
                        <label>States:</label>
                        <select class="form-control">
                           <option>Option 2</option>
                        </select>
                     </div>
                     <div class="form-group">
                        <label>Package Price:</label>
                        <input type="number" class="form-control">
                     </div>
                     <div class="form-group">
                        <label>GST(Applicatable):</label>
                        <select class="form-control">
                           <option>Option 2</option>
                        </select>
                     </div>
                     <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4>Package Description</h4>
                                </div>
                                <div class="card-body">
                                    <div class="form-group row mb-4">
                                        <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Description Type here.</label>
                                        <div class="col-sm-12 col-md-7">
                                            <textarea class="summernote"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                  </div>
                  <div class="card-footer text-right">
                     <button class="btn btn-primary">Content Post</button>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </section>
</div>
<!-- General JS Scripts -->
<script src="../assets/bundles/lib.vendor.bundle.js"></script>
<script src="../js/CodiePie.js"></script>

<!-- JS Libraies -->
<script src="../assets/modules/jquery.sparkline.min.js"></script>
<script src="../assets/modules/chart.min.js"></script>
<script src="../assets/modules/owlcarousel2/dist/owl.carousel.min.js"></script>
<script src="../assets/modules/summernote/summernote-bs4.js"></script>
<script src="../assets/modules/chocolat/dist/js/jquery.chocolat.min.js"></script>

<!-- Page Specific JS File -->
<script src="../js/page/index.js"></script>

<!-- Template JS File -->
<script src="../js/scripts.js"></script>
<script src="../js/custom.js"></script>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-lite.min.js"></script>