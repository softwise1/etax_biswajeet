
<?php 
session_start();
include('../config/dbcon.php');
?>

<?php
if(isset($_POST['cat_delete']))
{
    $cat_id = $_GET['cat_id'];
    $query = " DELETE FROM categories WHERE cat_id='$cat_id'";
    $query_run = mysqli_query($conn, $query);

    if($query_run)
    {
         $_SESSION['status'] = "Category Deleted Successfully";
            header("Location: ../includes/admin-category.php");
    }
    else{
        $_SESSION['status'] = "Category Deleted Failed";
            header("Location: ../includes/admin-category.php");
    }
}



?>