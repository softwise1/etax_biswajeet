
<?php 
session_start();
include('../config/dbcon.php');
?>
<?php

if(isset($_POST['category_add']))
{
    $cat_name = $_POST['cat_name'];
    $cat_desc = $_POST['cat_desc'];
    $meta_desc = $_POST['meta_desc'];


    $cat_query = "INSERT INTO categories (cat_name,cat_desc,meta_desc) VALUE ('$cat_name','$cat_desc','$meta_desc')";
    $cat_query_run = mysqli_query($conn, $cat_query);
    if($cat_query_run)
    {
        $_SESSION['status'] = "Category Inserted Successfully";
        header("Location: ../includes/admin-category.php");
    }
    else
    {
        $_SESSION['status'] = "Category Inserted Failed";
        header("Location: ../created/categories-created.php");
    }
}

// Sub Category Start

if(isset($_POST['subcategory_add']))
{
    $subcat_name = $_POST['subcat_name'];
    $subcat_desc = $_POST['subcat_desc'];
    $submeta_desc = $_POST['submeta_desc'];


    $subcat_query = "INSERT INTO subcategories (subcat_name,subcat_desc,submeta_desc) VALUE ('$subcat_name','$subcat_desc','$submeta_desc')";
    $subcat_query_run = mysqli_query($conn, $subcat_query);
    if($subcat_query_run)
    {
        $_SESSION['status'] = "SubCategory Inserted Successfully";
        header("Location: ../includes/admin-sub-category.php");
    }
    else
    {
        $_SESSION['status'] = "Category Inserted Failed";
        header("Location: ../created/sub-categories-created.php");
    }
}

// Sub Category End


?>